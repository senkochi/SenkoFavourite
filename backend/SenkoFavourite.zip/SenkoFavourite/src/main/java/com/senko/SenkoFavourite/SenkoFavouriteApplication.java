package com.senko.SenkoFavourite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SenkoFavouriteApplication {

	public static void main(String[] args) {
		SpringApplication.run(SenkoFavouriteApplication.class, args);
	}

}
