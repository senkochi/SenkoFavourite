package com.senko.SenkoFavourite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SenkoFavouriteApplicationTests {

	@Test
	void contextLoads() {
	}

}
